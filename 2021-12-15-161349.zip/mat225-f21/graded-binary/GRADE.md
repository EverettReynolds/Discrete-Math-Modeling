# Your grade

0.8/1

# Instructor comments

Need to return the whole list `result` at once rather than trying to do one digit at a time.  The `return` command only can be run once in a function.

# nbgrader

Your notebook was automatically graded using nbgrader, with
possible additional instructor tests.

TOTAL SCORE: 0/1

## nbgrader details


**binary.ipynb:**

| Problem   | Score     |
|:----------|:----------|
| 7dd5ce    | 0         |


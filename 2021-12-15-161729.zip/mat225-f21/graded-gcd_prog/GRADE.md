# Your grade

10/10

# nbgrader

Your notebook was automatically graded using nbgrader, with
possible additional instructor tests.

TOTAL SCORE: 0/3

## nbgrader details


**gcd.ipynb:**

| Problem   | Score     |
|:----------|:----------|
| a15fc2    | 0         |

